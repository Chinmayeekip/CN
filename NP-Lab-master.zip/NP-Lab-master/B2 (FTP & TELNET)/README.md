### Output

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B2%20(FTP%20%26%20TELNET)/output/b2_output-1.png)

![output-2](https://github.com/git-akshat/NP-Lab/blob/master/B2%20(FTP%20%26%20TELNET)/output/b2_output-2.png)