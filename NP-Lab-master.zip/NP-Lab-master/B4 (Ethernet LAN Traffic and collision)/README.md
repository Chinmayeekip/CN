### Output

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B4%20(Ethernet%20LAN%20Traffic%20and%20collision)/output/lab4_output.png)