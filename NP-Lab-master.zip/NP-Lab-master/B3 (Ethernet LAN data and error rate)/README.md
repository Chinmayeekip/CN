### Output

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B3%20(Ethernet%20LAN%20data%20and%20error%20rate)/output/b3_output.png)