### Output

![output-1](https://github.com/git-akshat/NP-Lab/blob/master/B1%20(P2P)/output/B1_terminal_output.png)

![output-2](https://github.com/git-akshat/NP-Lab/blob/master/B1%20(P2P)/output/B1_nam_output.png)